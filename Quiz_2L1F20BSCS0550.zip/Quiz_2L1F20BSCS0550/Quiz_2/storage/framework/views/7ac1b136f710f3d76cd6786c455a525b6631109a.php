<!DOCTYPE html>
<html>
<head>
	<title>Student Records</title>
	<style>
		table {
			border-collapse: collapse;
			width: 100%;
		}
		th, td {
			text-align: left;
			padding: 8px;
			border: 1px solid black;
		}
		th {
			background-color: #ddd;
			font-weight: bold;
		}
			button {
			background-color: #4CAF50;
			color: white;
			padding: 8px 16px;
			border: none;
			cursor: pointer;
		}
	</style>
</head>
<body>
	<h1>Student Records</h1>

	<input type="text" placeholder="Enter roll number to delete" id="search-input"><br>
	<button style="color:red" onclick="deleterecord()">Delete</button>
	<table>
		<thead>
			<tr>
				<th>ID</th>
				<th>Roll Number</th>
				<th>CGPA</th>
				
			</tr>
		</thead>
		<tbody>
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
           
			<tr>
				<td>00<?php echo e($stu->id); ?></td>
				<td><?php echo e($stu->rollno); ?></td>
				<td> <?php echo e($stu->cgpa); ?> </td>
				
			</tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
		</tbody>
	</table>
<button><a href="<?php echo e(url('/insert')); ?> ">Insert New Record</a></button>
<script>
    function deleterecord() {
        var rollno = document.getElementById('search-input').value;
  var deleteUrl = "<?php echo e(url('/delete')); ?>/" + rollno;

  
  window.location.href = deleteUrl;
    }




</script>
</body>
</html>
<?php /**PATH C:\Users\New\Desktop\Quiz_2\Quiz_2\resources\views/Table.blade.php ENDPATH**/ ?>