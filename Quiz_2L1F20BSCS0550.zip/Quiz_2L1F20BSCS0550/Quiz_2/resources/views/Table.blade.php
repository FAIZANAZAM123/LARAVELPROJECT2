<!DOCTYPE html>
<html>
<head>
	<title>Student Records</title>
	<style>
		table {
			border-collapse: collapse;
			width: 100%;
		}
		th, td {
			text-align: left;
			padding: 8px;
			border: 1px solid black;
		}
		th {
			background-color: #ddd;
			font-weight: bold;
		}
			button {
			background-color: #4CAF50;
			color: white;
			padding: 8px 16px;
			border: none;
			cursor: pointer;
		}
	</style>
</head>
<body>
	<h1>Student Records</h1>

	<input type="text" placeholder="Enter roll number to delete" id="search-input"><br>
	<button style="color:red" onclick="deleterecord()">Delete</button>
	<table>
		<thead>
			<tr>
				<th>ID</th>
				<th>Roll Number</th>
				<th>CGPA</th>
				
			</tr>
		</thead>
		<tbody>
            @foreach ($students as $stu)
                
           
			<tr>
				<td>00{{$stu->id}}</td>
				<td>{{$stu->rollno}}</td>
				<td> {{$stu->cgpa}} </td>
				
			</tr>
            @endforeach
			
		</tbody>
	</table>
<button><a href="{{url('/insert')}} ">Insert New Record</a></button>
<script>
    function deleterecord() {
        var rollno = document.getElementById('search-input').value;
  var deleteUrl = "{{ url('/delete') }}/" + rollno;

  
  window.location.href = deleteUrl;
    }




</script>
</body>
</html>
