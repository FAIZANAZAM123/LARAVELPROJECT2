<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use DB;
class StudentTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        $data = [
            ['id' =>001, 'rollno' =>12345 , 'cgpa'=>3.5],
            ['id' =>002, 'rollno' =>23456 , 'cgpa'=>3.2],
            ['id' =>003, 'rollno' =>34567 , 'cgpa'=>3.8],
            ['id' =>004, 'rollno' =>45678 , 'cgpa'=>3.4],

        ];
        \DB::table('students')->insert($data); 
    

    }
}
